# Changelog

## 2.1.1

- Convert specs to rspec3 syntax
- Fix metadata.json

## 2.1.0

- Support `action_port` and `action_protocol` parameters (GH #1)

## 2.0.0

- First release of split module.
