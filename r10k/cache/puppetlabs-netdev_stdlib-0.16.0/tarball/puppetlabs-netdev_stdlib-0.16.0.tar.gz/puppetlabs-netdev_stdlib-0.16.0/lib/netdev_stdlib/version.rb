module NetdevStdlib
  VERSION = '0.16.0'.freeze
end
