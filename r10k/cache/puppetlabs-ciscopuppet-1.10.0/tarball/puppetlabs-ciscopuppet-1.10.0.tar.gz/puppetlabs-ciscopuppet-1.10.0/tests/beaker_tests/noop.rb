# Dummy test for CI development
logger.info('TestCase :: NOOP :: START')
logger.info('TestCase :: NOOP :: END')
