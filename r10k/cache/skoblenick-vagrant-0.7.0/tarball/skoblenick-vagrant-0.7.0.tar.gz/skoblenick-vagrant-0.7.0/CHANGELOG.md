2014-04-09 - Ryan Skoblenick <ryan@skoblenick.com> - 0.7.0
  * Updated default versin of Vagrant to 1.5.2

2014-03-29 - Ryan Skoblenick <ryan@skoblenick.com> - 0.6.0
  * Added a bunch of conditional logic to construct the URL for download. This
    has become necessary because the URL pattern on Vagrant's site has changed
    again. Why can no one stick to simple URL consistent and common URL
    practices...

2014-03-14 - Ryan Skoblenick <ryan@skoblenick.com> - 0.5.1
  * Updated default version of Vagrant to 1.5.1

2014-03-03 - Ryan Skoblenick <ryan@skoblenick.com> - 0.5.0
  * Removed historical support for versions of Vagrant older than 1.4.0
  * At present this module will only support Vagrant 1.4.0+
  * Fixed installations for Linux distros [GH-1]. Module is now using osfamily

2013-10-19 - Ryan Skoblenick <ryan@skoblenick.com> - 0.4.0
  * Updated default version of Vagrant to 1.3.5
  * Added git hash for Vagrant 1.3.5

2013-10-02 - Ryan Skoblenick <ryan@skoblenick.com> - 0.3.0
  * Updated default version of Vagrant to 1.3.4
  * Added git hash for Vagrant 1.3.4

2013-09-22 - Ryan Skoblenick <ryan@skoblenick.com> - 0.2.0
  * Added version number to namevar of package type
  * Updated default version of Vagrant to 1.3.3
  * Added git hashes for Vagrant 1.3.2 and 1.3.3
  * Updated README
  * Added parameters list to comments in init.pp
  * Fixed comment in params.pp

2013-09-14 - Ryan Skoblenick <ryan@skoblenick.com> - 0.1.0
  * Initial version
