## [v1.1.0](https://github.com/voxpupuli/puppet-windows_firewall/tree/v1.1.0) (2017-02-11)

This is the last release with Puppet3 support!
* Fix several markdown issues
* Add missing badges
* Fix several rubocop issues
* Set min version_requirement for Puppet + bump deps
* Rubocop: automatic fixes

## 2016-05-08 Release 1.0.3

* modulesync with voxpupuli defaults

## 2016-02-03 Release 1.0.2

* Added support for matching remote ports


## 2015-07-23 Release 1.0.1

* Fixed rules not being deleted


## 2013-10-20 Release 0.0.3

* Add program rule support, various other fixes


## 2013-10-20 Release 0.0.2

* Some bug fixes and additional testing


## 2013-10-20 Release 0.0.1

* The initial version
