require 'netdev_stdlib/version'

module NetdevStdlib
end
