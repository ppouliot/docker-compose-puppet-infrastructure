## [v2.2.0](https://github.com/voxpupuli/puppet-msoffice/tree/v2.2.0) (2017-01-13)

This is the last release with Puppet 3 support!
* Set min version_requirement for Puppet + deps
* Modulesync with latest Vox Pupuli defaults

## 2016-10-27 - Release 2.1.0

  * [GH-33](https://github.com/voxpupuli/puppet-msoffice/issues/33) Support `puppetlabs/powershell` 2.x

## 2016-05-29 - Release 2.0.0

* drop ruby 1.8.0
* rubocop clean
* modulesync integrated
* moved to Voxpupuli

__0.0.2__
Added lots of testing and support for installing LIPs.

__0.0.1__
The initial proof-of-concept version
