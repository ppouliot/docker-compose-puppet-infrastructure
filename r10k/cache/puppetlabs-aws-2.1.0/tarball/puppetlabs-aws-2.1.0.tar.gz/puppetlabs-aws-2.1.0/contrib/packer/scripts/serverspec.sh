#!/bin/bash
cd /tmp/tests
rake spec
