# Changelog

## 3.0.0

- Fix support for 'puppet generate types'
- Remove misplaced stubs in spec tests
- Added CentOS and OracleLinux to supported OS list

## 2.0.2

- Upped supported Puppet versions to include Puppet 5

## 2.0.1

- Fix metadata.json
- Various minor updates to Travis test configuration

## 2.0.0

- First release of split module.
