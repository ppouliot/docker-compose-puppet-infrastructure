This module (`croddy/make`) has moved to the Vox Pupuli namespace for all future releases:

[Forge](https://forge.puppet.com/puppet/make)
[Github](https://github.com/voxpupuli/puppet-make)

See you on Freenode in `#voxpupuli`!
