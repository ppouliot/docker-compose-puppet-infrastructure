export HOMEBREW_CACHE="/Library/Caches/Homebrew"
export HOMEBREW_LOGS="/Library/Logs/Homebrew/"
