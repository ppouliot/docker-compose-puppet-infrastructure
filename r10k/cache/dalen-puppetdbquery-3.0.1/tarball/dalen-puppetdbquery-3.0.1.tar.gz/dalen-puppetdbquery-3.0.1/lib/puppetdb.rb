module PuppetDB
  # Current version of this module
  VERSION ||= [3, 0, 1].freeze
end
