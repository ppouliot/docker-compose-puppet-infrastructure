require 'puppet/application/face_base'

class Puppet::Application::Aci < Puppet::Application::FaceBase
end
