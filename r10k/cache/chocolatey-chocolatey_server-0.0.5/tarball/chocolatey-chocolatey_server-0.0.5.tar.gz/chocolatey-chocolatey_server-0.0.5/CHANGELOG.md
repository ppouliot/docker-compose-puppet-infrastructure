2016-10-11 Release 0.0.5
- Allow either chocolatey/chocolatey or puppetlabs/chocolatey [#11](https://github.com/chocolatey/puppet-chocolatey_server/issues/11)
- Support Windows 2008 [#7](https://github.com/chocolatey/puppet-chocolatey_server/issues/7)


2015-11-03 Release 0.0.4
- Allow overriding package location [#2](https://github.com/chocolatey/puppet-chocolatey_server/issues/2)
- Upper bound versions


2015-05-13 Release 0.0.3
- Update dependencies


2015-03-31 Release 0.0.2
- Fixed syntax error (marshyski)


2015-03-09 Release 0.0.1
- module skeleton, might work (probably not though)
