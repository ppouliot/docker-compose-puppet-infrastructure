## [v1.2.0](https://github.com/voxpupuli/puppet-windows_autoupdate/tree/v1.2.0) (2017-02-11)

This is the last release with Puppet3 support!
* Remove mixed case parameters, modulesync (0.3.0)
* Fix several Rubocop issues
* Fix several markdown issues
* Add missing badges
* Fix several rubocop issues
* Set min version_requirement for Puppet + bump deps

## 2016-03-29 Release 1.1.0

- Deprecate mixed case parameters

## 2015-03-19 Release 1.0.1

- fixing bug in puppet-community release

## 2015-03-19 Release 1.0.0

- first puppet-community supported version

## 2015-01-16 Release 0.1.0

- support for windows 2012

## 2013-05-01 Release 0.0.2

- less restrictive dependency on stdlib

## 2013-04-26 Release 0.0.1

- initial version
