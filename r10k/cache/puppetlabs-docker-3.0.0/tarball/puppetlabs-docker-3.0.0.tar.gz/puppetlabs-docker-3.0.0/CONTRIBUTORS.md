   554	Gareth Rushgrove
    25	Kyle Anderson
    14	Jo Vandeginste
    14	Andrew Teixeira
    11	Javier Bértoli
    10	Justin Dray
    10	Nikita Tarasov
    10	Vahram Sukyas
     9	Patrick Hemmer
     9	rafael_chicoli
     8	Jonathan Tripathy
     8	n0coast
     8	James Carr
     8	pandrew
     8	jfarrell
     7	Lars van de Kerkhof
     7	Lukas Waslowski
     7	Jean-Francois Roche
     7	Cornel Foltea
     7	Elias Probst
     6	Paul Morgan
     6	Alex Hornung
     6	Joshua Hoblitt
     6	Tomas Doran
     6	Scott Coulton
     5	Casper Bruun
     5	Camille Mougey
     5	paschdan
     5	Fredrik Thulin
     4	Cristian Falcas
     4	Janos Feher
     4	scott coulton
     4	Christophe Fonteyne
     4	Clayton O'Neill
     4	Vilmos Nebehaj
     4	Brandon Rochon
     4	Ben Langfeld
     4	Frank Kleine
     4	Bradley Cicenas
     4	Wim Bonthuis
     3	Edward Midolo
     3	Greg Hardy
     3	Jonathan Sokolowski
     3	hcguersoy
     3	Hylke Stapersma
     3	James Edwards
     3	Vikraman Choudhury
     3	Brian Johnson
     3	Thomas Krille
     3	Bryan Jen
     3	Terry Zink
     3	Ryan Fowler
     3	Rasmus Johansson
     3	Rafael Chicoli
     3	Daniel Platt
     3	Mason Malone
     3	Markus Frosch
     3	Darren Coxall
     3	Andrew Stangl
     3	David Schmitt
     3	Marji Cermak
     2	Sam Grimee
     2	Alex Crowe
     2	Alexandre RAOUL
     2	Benjamin Pineau
     2	Bill Simon
     2	Bob Potter
     2	Caleb Tomlinson
     2	Carles Amigó
     2	Daniel Panteleit
     2	David Danzilio
     2	Dominic Becker
     2	Hal Deadman
     2	Hunter Haugen
     2	Ilya Kalinin
     2	Jo Vanvoorden
     2	Joaquin
     2	Josh Samuelson
     2	Marc Schaer
     2	Mickaël PERRIN
     2	Nikita
     2	Paul Otto
     2	Reser, Ben
     2	Rhommel Lamas
     2	Ricardo Oliveira
     2	Ricky Cook
     2	Rob Terhaar
     2	Salimane Adjao Moustapha
     2	William Leese
     2	Wouter Scheele
     2	Zsolt Keseru
     2	bcicen
     2	coreone
     2	krall
     2	sebastian cole
     1	Felix Bechstein
     1	Justin Stoller
     1	Kasumi Hanazuki
     1	Keith Thornhill
     1	Eugene Malihins
     1	Elliot Huffman
     1	Dylan Cochran
     1	Maarten Claes
     1	Aron Parsons
     1	Mario Weigel
     1	Dmitriy Myaskovskiy
     1	Mark Kusch
     1	Darragh Bailey
     1	Martin Dietze
     1	Martin Prebio
     1	Daniel Werdermann
     1	Michael Gorsuch
     1	Michael Hackner
     1	Michael Wells
     1	Mick Pollard
     1	Mickaël FORTUNATO
     1	kasisnu
     1	Mike Terzo
     1	Nathan Flynn
     1	Nathan R Valentine
     1	Neil Parley
     1	keith
     1	Daniel Lawrence
     1	Oriol Fitó
     1	Daniel Klockenkämper
     1	Daniel Holz
     1	will vuong
     1	Pierre Radermecker
     1	Povilas Daukintis
     1	Colin Hebert
     1	Chris Wendt
     1	ladoe00
     1	mh
     1	mujiburger
     1	Andreas de Pretis
     1	Alexander Dudko
     1	Robin Westin Larsson
     1	Chris Hoffman
     1	Alex Elman
     1	Adam Stephens
     1	Sam Grimee (BDB)
     1	Sam Weston
     1	Saverio Proto
     1	Chris Crewdson
     1	Sean Sube
     1	Tassilo Schweyer
     1	Chadwick Banning
     1	Bryan Belanger
     1	Tim Bishop
     1	Tim Hartmann
     1	Tim Sharpe
     1	Tom De Vylder
     1	Tom Mast
     1	Bruno Léon
     1	Tomasz Tarczynski
     1	Brandon Weeks
     1	Vebjorn Ljosa
     1	Brad Cowie
     1	Benjamin Merot
     1	Adriaan Peeters
     1	Ben Ford
     1	sauce@freenode
     1	Adam Yohrling
     1	andygodwin
     1	willpayne
     1	bob
     1	James Abley
     1	James Green
     1	Jakub Husak
     1	Huaqing Zheng
     1	Harald Skoglund
     1	Jing Dong
     1	Hane, Jason
     1	ssube
     1	fluential
     1	Joaquin Henriquez
     1	Jonas Renggli
     1	HIngst, Arne-Kristian
     1	Grcic Ivan GEOINFO
     1	Jos Houtman
     1	Josef Johansson
     1	Josh Brown
     1	Arran Walker
     1	Geoff Meakin
     1	Joshua Spence
     1	Justin Riley
