# encoding: utf-8
#
# require 'spec_helper'
# describe 'netdev_stdlib_eos' do
#
#   context 'with defaults for all parameters' do
#     it { should contain_class('netdev_stdlib_eos') }
#   end
# end
