# Manifest examples

Examples are given below for each of the providers and custom types in
`augeasproviders`.

