## Maintenance

Maintainers:
  - Puppet Windows Team `windows |at| puppet |dot| com`

Tickets: https://tickets.puppet.com/browse/MODULES. Make sure to set component to `powershell`.
