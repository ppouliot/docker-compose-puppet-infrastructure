## [v2.1.0](https://github.com/voxpupuli/puppet-graphite_powershell/tree/v2.1.0) (2017-02-11)

This is the last release with Puppet3 support!
* Fix several markdown issues
* Add missing badges
* Add min version_requirement for Puppet + deps

## 2016-08-30 - Release 2.0.1

* Deploy to the forge (last release didn't work)

## 2016-08-19 - Release 2.0.0

* Drop of ruby1.8.7
* Modulesync with latest Vox Pupuli changes
* Fix: Hard coded path to config file in config class (issue #4)
* Alignment of licenses


## 2014-10-10 - Release 1.0.0

###Summary

* Updating documentation and metadata
* Bringing module up to a higher quality standard


## 2014-07-07 - Release 0.1.0

###Summary

* Initial version. Installs graphite powershell and configures the stats.
