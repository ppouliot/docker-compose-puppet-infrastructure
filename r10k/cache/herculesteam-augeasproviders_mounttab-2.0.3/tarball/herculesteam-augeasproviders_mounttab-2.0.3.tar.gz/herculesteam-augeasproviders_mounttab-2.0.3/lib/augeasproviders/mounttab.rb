require File.dirname(__FILE__) + '/../augeasproviders'

module AugeasProviders::Mounttab
end
