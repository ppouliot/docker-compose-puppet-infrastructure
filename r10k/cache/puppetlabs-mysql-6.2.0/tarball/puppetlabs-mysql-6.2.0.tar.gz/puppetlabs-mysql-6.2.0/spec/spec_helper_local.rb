require 'rspec-puppet-facts'
include RspecPuppetFacts
