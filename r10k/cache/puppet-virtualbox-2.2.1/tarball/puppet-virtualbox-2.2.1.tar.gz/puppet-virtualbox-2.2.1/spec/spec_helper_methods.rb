def fixture_path
  File.expand_path(File.join(__FILE__, '..', 'fixtures'))
end
