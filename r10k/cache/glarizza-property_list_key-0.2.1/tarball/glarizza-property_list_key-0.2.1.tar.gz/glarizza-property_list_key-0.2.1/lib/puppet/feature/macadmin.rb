require 'puppet/util/feature'
Puppet.features.add(:macadmin, :libs => ['macadmin'])
