module AugeasProviders
end
