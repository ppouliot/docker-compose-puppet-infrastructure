2014-03-30 - Ryan Skoblenick <ryan@skoblenick.com> - 0.4.0
  * Updated default version to 1.8.1

2013-10-07 - Ryan Skoblenick <ryan@skoblenick.com> - 0.3.0
  * Updated default version to 1.7.3

2013-09-16 - Ryan Skoblenick <ryan@skoblenick.com> - 0.2.0
  * Updated default version to 1.7.0.1
  * Added parameters list to init script

2013-09-15 - Ryan Skoblenick <ryan@skoblenick.com> - 0.1.0
  * Initial version
