require 'puppet/util/feature'

Puppet.features.add(:aws, libs: 'aws-sdk')
