## [v0.4.0](https://github.com/voxpupuli/puppet-community_kickstarts/tree/v0.4.0) (2017-02-10)

This is the last release with puppet3 support!

## 2016-08-02 - Release 0.3.4

* The previous release didn't make it to the forge (again again) because of an issue with travis


## 2016-08-01 - Release 0.3.3

* The previous release didn't make it to the forge (again) because of an issue with travis


## 2016-08-01 - Release 0.3.2

* The previous release didn't make it to the forge because of an issue with travis


## 2016-07-29 - Release 0.3.1

* modulesync with latest voxpupuli defaults (fixes broken tests)


## 2016-06-12 - Release 0.3.0

* Drop Ruby1.8 Support
* modulesync with latest voxpupuli defaults


## 2016-02-09 Release 0.2.3

* Properly support $fragments and variables for scoping. Properly sets the puppet repo value.


## 2016-01-08 Release 0.2.2

* Add puppetforge auto deploy capabilities
* Enhance the CentOS7 type after more thorough testing


## Release 0.1.0

* Introduce community_kickstarts with one type, CentOS7
