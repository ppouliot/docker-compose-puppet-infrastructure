# Changelog

## 2.1.1

- Upped supported Puppet versions to include Puppet 5 

## 2.1.0

- Support forced positioning (thanks to Michael Marod)
- Do not version Gemfile.lock
- Sudo needed on Travis
- Update copyright
- Improve README

## 2.0.3

- Add requirements to metadata.json

## 2.0.2

- Fix metadata.json

## 2.0.1

- Remove erratic symlink in spec directory

## 2.0.0

- First release of split module.
