require 'puppet/application/face_base'

class Puppet::Application::Docker < Puppet::Application::FaceBase
end
