# Changelog

## 2.0.1

- Fix metadata.json
- Various minor updates to Travis test configuration

## 2.0.0

- First release of split module.
