# Changelog

## 3.0.0

- Fix support for 'puppet generate types'
- Added CentOS and OracleLinux to supported OS list

## 2.0.4

- Upped supported Puppet versions to include Puppet 5

## 2.0.3

- Add requirements to metadata.json

## 2.0.2

- Convert specs to rspec3 syntax
- Fix metadata.json

## 2.0.1

- Remove erratic symlink in spec directory

## 2.0.0

- First release of split module.
