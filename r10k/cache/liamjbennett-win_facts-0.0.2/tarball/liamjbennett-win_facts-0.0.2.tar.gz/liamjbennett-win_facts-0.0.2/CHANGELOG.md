0.0.2
Fixed issue #3 with a constant defintion conflicting with the puppetlabs/registry module
Fixed issue #1 with systemtype reporting incorrectly on some version of windows

0.0.1
The initial version
