# Changelog

## 2.1.1

- Upped supported Puppet versions to include Puppet 5

## 2.1.0

- Use $confdir instead of static path

## 2.0.2

- Add requirements in metadata.json

## 2.0.1

- Convert specs to rspec3 syntax
- Fix metadata.json

## 2.0.0

- First release of split module.
