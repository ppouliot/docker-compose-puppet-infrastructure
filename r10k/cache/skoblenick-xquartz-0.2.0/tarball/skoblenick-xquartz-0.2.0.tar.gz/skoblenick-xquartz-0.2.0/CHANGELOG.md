2014-03-30 Ryan Skoblenick <ryan@skoblenick.com> - 0.2.0
  * Updated default version of XQuartz to 2.7.5
  * Fixed link in README to show list of available versions

2013-09-22- Ryan Skoblenick <ryan@skoblenick.com> - 0.1.0
  * Initial version
