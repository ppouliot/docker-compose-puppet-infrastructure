require 'puppet/util/feature'

Puppet.features.add(:augeas, libs: ['augeas'])
