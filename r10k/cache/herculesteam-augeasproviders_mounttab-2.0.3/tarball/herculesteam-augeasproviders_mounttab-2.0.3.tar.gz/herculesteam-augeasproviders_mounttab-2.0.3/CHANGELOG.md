# Changelog

## 2.0.3

- Added a hard requirement to the metadata.json for puppetlabs/mount_providers

## 2.0.2

- Upped supported Puppet versions to include Puppet 5

## 2.0.1

- Fix metadata.json
- Various minor updates to Travis test configuration

## 2.0.0

- First release of split module.
