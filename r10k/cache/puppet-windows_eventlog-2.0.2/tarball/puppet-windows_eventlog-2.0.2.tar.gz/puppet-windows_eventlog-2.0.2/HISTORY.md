## [v1.2.0](https://github.com/voxpupuli/puppet-windows_eventlog/tree/v1.2.0) (2017-02-11)

This is the last release with Puppet3 support!
* Sync metadata.json license to be same as LICENSE
* Fix several Rubocop issues
* Fix several markdown issues
* Add missing badges
* Fix several rubocop issues
* Set min version_requirement for Puppet + bump deps

## 2016-05-08 Release 1.1.1

* modulesync with voxpupuli defaults

## 2015-05-15 Release 1.1.0 (not published)

* Infer log_path using $name (when log_path is unset)

## 0.0.1

* The initial version
