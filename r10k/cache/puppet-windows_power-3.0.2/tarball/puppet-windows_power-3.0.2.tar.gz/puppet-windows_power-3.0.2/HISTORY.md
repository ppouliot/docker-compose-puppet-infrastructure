## [v2.0.0](https://github.com/voxpupuli/puppet-windows_power/tree/v2.0.0) (2017-02-11)

This is the last release with Puppet3 support!
* Drop of ruby187 support!
* Fix several rubocop issues
* rubocop: fix RSpec/ImplicitExpect
* Modulesync

## 2015-03-23 Release 1.0.0
- Initial module release to voxpupuli
