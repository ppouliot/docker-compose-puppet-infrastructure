Puppet.features.add(:json, :libs => ["json"])
