require 'pathname'

Puppet::Type.newtype(:dsc_spuserprofileserviceapp) do
  require Pathname.new(__FILE__).dirname + '../../' + 'puppet/type/base_dsc'
  require Pathname.new(__FILE__).dirname + '../../puppet_x/puppetlabs/dsc_type_helpers'


  @doc = %q{
    The DSC SPUserProfileServiceApp resource type.
    Automatically generated from
    'SharePointDsc/DSCResources/MSFT_SPUserProfileServiceApp/MSFT_SPUserProfileServiceApp.schema.mof'

    To learn more about PowerShell Desired State Configuration, please
    visit https://technet.microsoft.com/en-us/library/dn249912.aspx.

    For more information about built-in DSC Resources, please visit
    https://technet.microsoft.com/en-us/library/dn249921.aspx.

    For more information about xDsc Resources, please visit
    https://github.com/PowerShell/DscResources.
  }

  validate do
      fail('dsc_name is a required attribute') if self[:dsc_name].nil?
    end

  def dscmeta_resource_friendly_name; 'SPUserProfileServiceApp' end
  def dscmeta_resource_name; 'MSFT_SPUserProfileServiceApp' end
  def dscmeta_module_name; 'SharePointDsc' end
  def dscmeta_module_version; '2.2.0.0' end

  newparam(:name, :namevar => true ) do
  end

  ensurable do
    newvalue(:exists?) { provider.exists? }
    newvalue(:present) { provider.create }
    newvalue(:absent)  { provider.destroy }
    defaultto { :present }
  end

  # Name:         PsDscRunAsCredential
  # Type:         MSFT_Credential
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_psdscrunascredential) do
    def mof_type; 'MSFT_Credential' end
    def mof_is_embedded?; true end
    desc "PsDscRunAsCredential"
    validate do |value|
      unless value.kind_of?(Hash)
        fail("Invalid value '#{value}'. Should be a hash")
      end
      PuppetX::Dsc::TypeHelpers.validate_MSFT_Credential("Credential", value)
    end
  end

  # Name:         Name
  # Type:         string
  # IsMandatory:  True
  # Values:       None
  newparam(:dsc_name) do
    def mof_type; 'string' end
    def mof_is_embedded?; false end
    desc "Name - The name of the user profile service"
    isrequired
    validate do |value|
      unless value.kind_of?(String)
        fail("Invalid value '#{value}'. Should be a string")
      end
    end
  end

  # Name:         ProxyName
  # Type:         string
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_proxyname) do
    def mof_type; 'string' end
    def mof_is_embedded?; false end
    desc "ProxyName - The proxy name, if not specified will be /Name of service app/ Proxy"
    validate do |value|
      unless value.kind_of?(String)
        fail("Invalid value '#{value}'. Should be a string")
      end
    end
  end

  # Name:         ApplicationPool
  # Type:         string
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_applicationpool) do
    def mof_type; 'string' end
    def mof_is_embedded?; false end
    desc "ApplicationPool - The name of the application pool to run the service app in"
    validate do |value|
      unless value.kind_of?(String)
        fail("Invalid value '#{value}'. Should be a string")
      end
    end
  end

  # Name:         MySiteHostLocation
  # Type:         string
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_mysitehostlocation) do
    def mof_type; 'string' end
    def mof_is_embedded?; false end
    desc "MySiteHostLocation - The URL of the my site host collection"
    validate do |value|
      unless value.kind_of?(String)
        fail("Invalid value '#{value}'. Should be a string")
      end
    end
  end

  # Name:         ProfileDBName
  # Type:         string
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_profiledbname) do
    def mof_type; 'string' end
    def mof_is_embedded?; false end
    desc "ProfileDBName - The name of the profile database"
    validate do |value|
      unless value.kind_of?(String)
        fail("Invalid value '#{value}'. Should be a string")
      end
    end
  end

  # Name:         ProfileDBServer
  # Type:         string
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_profiledbserver) do
    def mof_type; 'string' end
    def mof_is_embedded?; false end
    desc "ProfileDBServer - The name of the server to host the profile database"
    validate do |value|
      unless value.kind_of?(String)
        fail("Invalid value '#{value}'. Should be a string")
      end
    end
  end

  # Name:         SocialDBName
  # Type:         string
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_socialdbname) do
    def mof_type; 'string' end
    def mof_is_embedded?; false end
    desc "SocialDBName - The name of the social database"
    validate do |value|
      unless value.kind_of?(String)
        fail("Invalid value '#{value}'. Should be a string")
      end
    end
  end

  # Name:         SocialDBServer
  # Type:         string
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_socialdbserver) do
    def mof_type; 'string' end
    def mof_is_embedded?; false end
    desc "SocialDBServer - The name of the database server to host the social database"
    validate do |value|
      unless value.kind_of?(String)
        fail("Invalid value '#{value}'. Should be a string")
      end
    end
  end

  # Name:         SyncDBName
  # Type:         string
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_syncdbname) do
    def mof_type; 'string' end
    def mof_is_embedded?; false end
    desc "SyncDBName - The name of the sync database"
    validate do |value|
      unless value.kind_of?(String)
        fail("Invalid value '#{value}'. Should be a string")
      end
    end
  end

  # Name:         SyncDBServer
  # Type:         string
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_syncdbserver) do
    def mof_type; 'string' end
    def mof_is_embedded?; false end
    desc "SyncDBServer - The name of the database server to host the sync database"
    validate do |value|
      unless value.kind_of?(String)
        fail("Invalid value '#{value}'. Should be a string")
      end
    end
  end

  # Name:         EnableNetBIOS
  # Type:         boolean
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_enablenetbios) do
    def mof_type; 'boolean' end
    def mof_is_embedded?; false end
    desc "EnableNetBIOS - Whether Farm should resolve NetBIOS domain names"
    validate do |value|
    end
    newvalues(true, false)
    munge do |value|
      PuppetX::Dsc::TypeHelpers.munge_boolean(value.to_s)
    end
  end

  # Name:         NoILMUsed
  # Type:         boolean
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_noilmused) do
    def mof_type; 'boolean' end
    def mof_is_embedded?; false end
    desc "NoILMUsed - Specifies if the service application should be configured to use AD Import"
    validate do |value|
    end
    newvalues(true, false)
    munge do |value|
      PuppetX::Dsc::TypeHelpers.munge_boolean(value.to_s)
    end
  end

  # Name:         Ensure
  # Type:         string
  # IsMandatory:  False
  # Values:       ["Present", "Absent"]
  newparam(:dsc_ensure) do
    def mof_type; 'string' end
    def mof_is_embedded?; false end
    desc "Ensure - Present if the service app should exist, absent if it should not Valid values are Present, Absent."
    validate do |value|
      resource[:ensure] = value.downcase
      unless value.kind_of?(String)
        fail("Invalid value '#{value}'. Should be a string")
      end
      unless ['Present', 'present', 'Absent', 'absent'].include?(value)
        fail("Invalid value '#{value}'. Valid values are Present, Absent")
      end
    end
  end

  # Name:         InstallAccount
  # Type:         MSFT_Credential
  # IsMandatory:  False
  # Values:       None
  newparam(:dsc_installaccount) do
    def mof_type; 'MSFT_Credential' end
    def mof_is_embedded?; true end
    desc "InstallAccount - POWERSHELL 4 ONLY: The account to run this resource as, use PsDscRunAsCredential if using PowerShell 5"
    validate do |value|
      unless value.kind_of?(Hash)
        fail("Invalid value '#{value}'. Should be a hash")
      end
      PuppetX::Dsc::TypeHelpers.validate_MSFT_Credential("InstallAccount", value)
    end
  end


  def builddepends
    pending_relations = super()
    PuppetX::Dsc::TypeHelpers.ensure_reboot_relationship(self, pending_relations)
  end
end

Puppet::Type.type(:dsc_spuserprofileserviceapp).provide :powershell, :parent => Puppet::Type.type(:base_dsc).provider(:powershell) do
  confine :true => (Gem::Version.new(Facter.value(:powershell_version)) >= Gem::Version.new('5.0.10586.117'))
  defaultfor :operatingsystem => :windows

  mk_resource_methods
end
