#!/usr/bin/env rspec

require 'spec_helper'

provider_class = Puppet::Type.type(:pg_hba).provider(:augeas)
def valid_lens?
  # This lens breaks on Augeas 0.10.0
  Puppet::Util::Package.versioncmp(Puppet::Type.type(:pg_hba).provider(:augeas).aug_version, '0.10.0') > 0
end

RSpec.configure do |c|
  c.filter_run_excluding :composite => false
end

if Puppet.version =~ /^0\./
  composite_supported = false
else
  composite_supported = true
end

describe provider_class, :if => valid_lens? do
  context "when composite namevars are supported", :composite => composite_supported do
    before(:all) { @tmpdir = Dir.mktmpdir }
    after(:all) { FileUtils.remove_entry_secure @tmpdir }

    context "with no existing file" do
      let(:target) { File.join(@tmpdir, "new_file") }

      it "should create simple new local entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on all",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse(target, "Pg_hba.lns", '
           { "1"
             { "type" = "local" }
             { "database" = "all" }
             { "user" = "all" }
             { "method" = "md5" }
           }
        ')
      end
    end

    context "with empty file" do
      let(:tmptarget) { aug_fixture("empty") }
      let(:target) { tmptarget.path }

      it "should create simple new local entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on all",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse(target, "Pg_hba.lns", '
           { "1"
             { "type" = "local" }
             { "database" = "all" }
             { "user" = "all" }
             { "method" = "md5" }
           }
        ')
      end

      it "should create two new entries" do
        apply!(
          Puppet::Type.type(:pg_hba).new(
            :name     => "local to all on all",
            :method   => "md5",
            :target   => target,
            :provider => "augeas"
          ),
          Puppet::Type.type(:pg_hba).new(
            :name     => "host to all on all from 192.168.0.1",
            :method   => "md5",
            :target   => target,
            :provider => "augeas"
          )
        )

        aug_open(target, "Pg_hba.lns") do |aug|
          expect(aug.match("*[method='md5']").size).to eq(2)
        end
      end

      context 'when specifying target in namevar' do
        it "should create simple new local entry" do
          apply!(Puppet::Type.type(:pg_hba).new(
            :name     => "local to all on all in #{target}",
            :method   => "md5",
            :provider => "augeas"
          ))

          augparse(target, "Pg_hba.lns", '
             { "1"
               { "type" = "local" }
               { "database" = "all" }
               { "user" = "all" }
               { "method" = "md5" }
             }
          ')
        end
      end

      it "should create simple new local entry with random namevar and using default" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "A local entry",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse(target, "Pg_hba.lns", '
           { "1"
             { "type" = "local" }
             { "database" = "all" }
             { "user" = "all" }
             { "method" = "md5" }
           }
        ')
      end

      it "should create simple new local entry with options" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on all",
          :method   => "ident",
          :options  => {
            'sameuser'   => :undef,
            'krb_realm'  => 'EXAMPLE.COM',
            'ldapsuffix' => ',ou=people,dc=example,dc=com',
            },
          :target   => target,
          :provider => "augeas"
        ))

        # Options can be in various orders (hash)
        aug_open(target, "Pg_hba.lns") do |aug|
          expect(aug.match("*/method/option[.='sameuser']").size).to eq(1)
          expect(aug.match("*/method/option[.='krb_realm' and value='EXAMPLE.COM']").size).to eq(1)
          expect(aug.match("*/method/option[.='ldapsuffix' and value=',ou=people,dc=example,dc=com']").size).to eq(1)
        end
      end

      it "should create simple new host entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "host to all on all from 1.2.3.4",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse(target, "Pg_hba.lns", '
           { "1"
             { "type" = "host" }
             { "database" = "all" }
             { "user" = "all" }
             { "address" = "1.2.3.4" }
             { "method" = "md5" }
           }
        ')
      end

      it "should create new local entry with multiple users and databases" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to +titi,@toto on db1,db2",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse(target, "Pg_hba.lns", '
           { "1"
             { "type" = "local" }
             { "database" = "db1" }
             { "database" = "db2" }
             { "user" = "+titi" }
             { "user" = "@toto" }
             { "method" = "md5" }
           }
        ')
      end

      it "should create new local entry with multiple users and databases using personalized namevar" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "+titi and @toto on db1 and db2",
          :user     => ['+titi', '@toto'],
          :database => ['db1', 'db2'],
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse(target, "Pg_hba.lns", '
           { "1"
             { "type" = "local" }
             { "database" = "db1" }
             { "database" = "db2" }
             { "user" = "+titi" }
             { "user" = "@toto" }
             { "method" = "md5" }
           }
        ')
      end
    end

    context "with full file" do
      let(:tmptarget) { aug_fixture("full") }
      let(:target) { tmptarget.path }

      it "should create new entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on mydb",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "*[database='mydb']", '
           { "1"
             { "type" = "local" }
             { "database" = "mydb" }
             { "user" = "all" }
             { "method" = "md5" }
           }
        ')
      end

      it "should create new entry after first entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on mydb",
          :position => "after *[type][1]",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "./2", '
           { "1"
             { "type" = "local" }
             { "database" = "mydb" }
             { "user" = "all" }
             { "method" = "md5" }
           }
        ')
      end

      it "should create new entry before first entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on mydb",
          :position => "before *[type][1]",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "./1", '
           { "1"
             { "type" = "local" }
             { "database" = "mydb" }
             { "user" = "all" }
             { "method" = "md5" }
           }
        ')
      end

      it "should create new entry before first entry using shortcut" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on mydb",
          :position => "before first entry",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "./1", '
           { "1"
             { "type" = "local" }
             { "database" = "mydb" }
             { "user" = "all" }
             { "method" = "md5" }
           }
        ')
      end

      it "should create new entry before last entry using shortcut" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on mydb",
          :position => "before last entry",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "./16", '
           { "1"
             { "type" = "local" }
             { "database" = "mydb" }
             { "user" = "all" }
             { "method" = "md5" }
           }
        ')
      end

      it "should create new entry after first host using shortcut" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on mydb",
          :position => "after first host",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "./3", '
           { "1"
             { "type" = "local" }
             { "database" = "mydb" }
             { "user" = "all" }
             { "method" = "md5" }
           }
        ')
      end

      it "should create new entry before last anyhost using shortcut" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on mydb",
          :position => "before last anyhost",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "./11", '
           { "1"
             { "type" = "local" }
             { "database" = "mydb" }
             { "user" = "all" }
             { "method" = "md5" }
           }
        ')
      end

      it "should delete local entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on all",
          :ensure   => "absent",
          :target   => target,
          :provider => "augeas"
        ))

        aug_open(target, "Pg_hba.lns") do |aug|
          expect(aug.match("*[type='local' and user='all' and database='all']")).to eq([])
        end
      end

      it "should update value of local entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on all",
          :method   => "bar",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "*[type='local' and user='all' and database='all']", '
           { "1"
             { "type" = "local" }
             { "database" = "all" }
             { "user" = "all" }
             { "method" = "bar" }
           }
        ')
      end

      it "should update value of local entry with options" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on all",
          :method   => "ident",
          :options  => {
            'sameuser' => :undef,
            },
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "*[type='local' and user='all' and database='all']", '
           { "1"
             { "type" = "local" }
             { "database" = "all" }
             { "user" = "all" }
             { "method" = "ident"
               { "option" = "sameuser" } }
           }
        ')
      end

      it "should move first entry after last entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on all",
          :ensure   => "positioned",
          :method   => "trust",
          :position => "after last entry",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "./16", '
           { "1"
             { "type" = "local" }
             { "database" = "all" }
             { "user" = "all" }
             { "method" = "trust" }
           }
        ')
      end

      it "should move entry before first host" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "local to sameuser on all",
          :ensure   => "positioned",
          :method   => "md5",
          :position => "before first host",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "./2", '
           { "1"
             { "type" = "local" }
             { "database" = "all" }
             { "user" = "sameuser" }
             { "method" = "md5" }
           }
        ')
      end

      it "should create simple new host entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "host to all on all from 1.2.3.4",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "*[type='host' and user='all' and database='all' and address='1.2.3.4']", '
           { "1"
             { "type" = "host" }
             { "database" = "all" }
             { "user" = "all" }
             { "address" = "1.2.3.4" }
             { "method" = "md5" }
           }
        ')
      end

      it "should delete host entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "host to all on all from 127.0.0.1/32",
          :ensure   => "absent",
          :target   => target,
          :provider => "augeas"
        ))

        aug_open(target, "Pg_hba.lns") do |aug|
          expect(aug.match("*[type='host' and user='all' and database='all' and address='127.0.0.1/32']")).to eq([])
        end
      end

      it "should update value of host entry" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "host to all on all from 127.0.0.1/32",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        augparse_filter(target, "Pg_hba.lns", "*[type='host' and user='all' and database='all' and address='127.0.0.1/32']", '
           { "1"
             { "type" = "host" }
             { "database" = "all" }
             { "user" = "all" }
             { "address" = "127.0.0.1/32" }
             { "method" = "md5" }
           }
        ')
      end

      it "should update value of host entry with options" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "host to all on all from 192.168.0.0/16",
          :method   => "ident",
          :options  => {
            'sameuser' => :undef,
            'map'      => 'omicron',
            },
          :target   => target,
          :provider => "augeas"
        ))

        aug_open(target, "Pg_hba.lns") do |aug|
          expect(aug.match("*[address='192.168.0.0/16']/method/option[.='sameuser']").size).to eq(1)
          expect(aug.match("*[address='192.168.0.0/16']/method/option[.='map' and value='omicron']").size).to eq(1)
        end
      end

      it "should update value of host entry with options removed" do
        apply!(Puppet::Type.type(:pg_hba).new(
          :name     => "host to all on all from 192.168.0.0/16",
          :method   => "ident",
          :options  => {
            'sameuser' => :undef,
            },
          :target   => target,
          :provider => "augeas"
        ))

        aug_open(target, "Pg_hba.lns") do |aug|
          expect(aug.match("*[address='192.168.0.0/16']/method/option[.='sameuser']").size).to eq(1)
          expect(aug.match("*[address='192.168.0.0/16']/method/option[.='map' and value='omicron']").size).to eq(0)
        end
      end
    end

    context "with broken file" do
      let(:tmptarget) { aug_fixture("broken") }
      let(:target) { tmptarget.path }

      it "should fail to load" do
        txn = apply(Puppet::Type.type(:pg_hba).new(
          :name     => "local to all on all",
          :method   => "md5",
          :target   => target,
          :provider => "augeas"
        ))

        expect(txn.any_failed?).not_to eq(nil)
        expect(@logs.first.level).to eq(:err)
        expect(@logs.first.message.include?(target)).to eq(true)
      end
    end
  end
end
