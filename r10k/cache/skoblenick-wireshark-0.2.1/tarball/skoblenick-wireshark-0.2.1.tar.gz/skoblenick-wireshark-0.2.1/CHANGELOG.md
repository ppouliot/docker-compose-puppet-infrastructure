2014-03-30 - Ryan Skoblenick <ryan@skoblenick.com> - 0.2.1
  * Fixed default version to 1.10.6 in params.pp
  * Fixed incorrect date in CHANGELOG

2014-03-30 - Ryan Skoblenick <ryan@skoblenick.com> - 0.2.0
  * Updated default version to 1.10.6

2013-09-28 - Ryan Skoblenick <ryan@skoblenick.com> - 0.1.1
  * Fixed missing dependency installation for Xquartz

2013-09-22 - Ryan Skoblenick <ryan@skoblenick.com> - 0.1.0
  * Initial version
