## Unsupported Release 0.1.1
### Summary
Patch release related to https://tickets.puppetlabs.com/browse/PE-20229. Repairs prefetch/resource state issue on AIX systems.

## 2014-11-18 - Release 0.1.0

- Initial release
