## [v0.4.0](https://github.com/voxpupuli/puppet-gerrit/tree/v0.4.0) (2017-02-11)

This is the last release with Puppet3 support!
* Add minimal documentation
* Add missing contribution file
* Add missing badges
* rubocop: fix RSpec/ImplicitExpect
* Set minimum version_requirement for Puppet + dep

## 2016-08-19 Release 0.3.0

* Initial release in the VoX Pupuli namespace (module provided by roidelapluie)
* Modulesync with latest Vox Pupuli defaults
