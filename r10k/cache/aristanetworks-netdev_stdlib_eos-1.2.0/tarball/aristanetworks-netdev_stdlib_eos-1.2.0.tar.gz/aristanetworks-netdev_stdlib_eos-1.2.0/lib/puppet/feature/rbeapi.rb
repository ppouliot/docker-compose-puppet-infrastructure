require 'puppet/util/feature'

Puppet.features.add(:rbeapi, libs: ['rbeapi'])
